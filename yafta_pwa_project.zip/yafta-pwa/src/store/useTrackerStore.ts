import { create } from 'zustand';

export interface ProjectState {
  id: string;
  clientName: string;
  title: string;
  stage: 'design' | 'production' | 'installation' | 'delivery';
  progressPercentage: number;
  mediaUpdates: string[];
  lastUpdated: string;
}

interface TrackerStore {
  activeProjects: ProjectState[];
  isSubscribing: boolean;
  error: string | null;
}

export const useTrackerStore = create<TrackerStore>(() => ({
  activeProjects: [
    {
      id: "YFT-702",
      clientName: "العميل الافتراضي",
      title: "واجهة حروف بارزة 3D ومطبوعات لشركة يافطة",
      stage: "production",
      progressPercentage: 45,
      mediaUpdates: [],
      lastUpdated: "2026-06"
    }
  ],
  isSubscribing: false,
  error: null
}));
