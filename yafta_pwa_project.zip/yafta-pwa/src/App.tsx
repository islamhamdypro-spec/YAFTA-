import React from 'react';
import { ParticleSystem } from './components/Shared/ParticleSystem';
import { GlassCard } from './components/ui/GlassCard';

function App() {
  return (
    <div className="relative min-h-screen bg-brand-black text-brand-text flex items-center justify-center p-4 selection:bg-brand-gold selection:text-brand-black" dir="rtl">
      <ParticleSystem />
      
      <GlassCard className="w-full max-w-md p-8 relative z-10 text-center flex flex-col items-center">
        {/* استدعاء ملف الشعار المطلوب نصاً وحرفاً كخلفية أو عنصر أساسي */}
        <img 
          src="/assets/branding/YAFTA_logo_1024_transparent (2).png" 
          alt="YAFTA Logo" 
          className="w-48 h-auto animate-float-3d mb-6 filter drop-shadow-[0_0_15px_rgba(201,152,28,0.4)]"
          onError={(e) => {
            // حل بديل في حال لم يتم وضع الصورة الفعالة بعد في مجلدassets
            e.currentTarget.style.display = 'none';
          }}
        />
        <h1 className="font-arabic font-bold text-3xl text-brand-gold mb-2">يافطة للدعاية والإعلان</h1>
        <p className="font-arabic text-sm text-brand-text/70 mb-6">"نحو عالم من الإبداع بلا حدود"</p>
        
        <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-brand-gold/30 to-transparent mb-6" />
        
        <button className="relative w-full py-3 bg-brand-gold text-brand-black font-arabic font-bold rounded-lg overflow-hidden group active:scale-[0.97] transition-transform">
          <span className="relative z-10">ابدأ رحلتك الإبداعية</span>
          <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:animate-shimmer-sweep" />
        </button>
      </GlassCard>
    </div>
  );
}

export default App;
