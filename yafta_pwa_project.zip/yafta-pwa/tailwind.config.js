/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          black: '#0A0A0A',
          surface: '#111111',
          gold: '#C9981C',
          goldLight: '#FFE066',
          text: '#F5F0E8',
        }
      },
      fontFamily: {
        arabic: ['Cairo', 'Noto Kufi Arabic', 'sans-serif'],
        heading: ['Playfair Display', 'serif'],
        body: ['Inter', 'sans-serif'],
      },
      animation: {
        'shimmer-sweep': 'shimmerSweep 1.5s infinite linear',
        'galaxy-vortex': 'vortexRotation 30s infinite linear',
        'float-3d': 'float3D 4s ease-in-out infinite',
      },
      keyframes: {
        shimmerSweep: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        vortexRotation: {
          '0%': { transform: 'rotate(0deg) scale(1)' },
          '50%': { transform: 'rotate(180deg) scale(1.1)' },
          '100%': { transform: 'rotate(360deg) scale(1)' },
        },
        float3D: {
          '0%, 100%': { transform: 'translateY(0) rotateX(0deg) rotateY(0deg)' },
          '50%': { transform: 'translateY(-12px) rotateX(4deg) rotateY(2deg)' },
        }
      }
    },
  },
  plugins: [],
}
